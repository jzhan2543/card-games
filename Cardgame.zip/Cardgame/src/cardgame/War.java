/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardgame;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;
import java.awt.Image;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author tonyzhang
 */
public class War extends javax.swing.JFrame {

    /**
     * Creates new form War
     */
    public War() {
        initComponents();
        initDeck();
    }
    
    public void initDeck() {
        //Creates and shuffles a new deck, seperates the deck evenly to two decks;
        boolean acehigh = true;
        Deck deck = new Deck(acehigh);
        deck.shuffle();
        //Deck userDeck = new Deck();
        for (int i = 0; i < 26; i++) {
            userDeck.addCard(deck.getCard(i),i);
        }
        //Deck computerDeck = new Deck();
        for (int i = 26; i < 52; i++) {
            computerDeck.addCard(deck.getCard(i),i - 26);
        }
    }

    public static Deck userDeck = new Deck();
    public static Deck computerDeck = new Deck();
    public static Card leftCard;
    public static Card rightCard;

    public void playWar(Deck uDeck, Deck cDeck) {
        int count = 0;
        //Create two new temporary decks to be assigned after War
        Deck newUserDeck = new Deck();
        Deck newComputerDeck = new Deck();
        //Creates two Cards that are the top cards of the user's and computer's deck
        Card u = uDeck.getCard(0);
        Card c = cDeck.getCard(0);
        //If the user's top card is larger
        if (u.getValue() > c.getValue()) {
            jTextArea1.append("Your " + u.toString() + " is greater than " + c.toString() + "\n");
            leftCard = uDeck.removeCard(0);
            rightCard = cDeck.removeCard(0);
            uDeck.addCard(u);
            uDeck.addCard(c);
        }
        //If the computer's top card is larger
        else if (u.getValue() < c.getValue()) {
            jTextArea1.append("The Computer's " + c.toString() + " is greater than " + u.toString() + "\n");
            leftCard = uDeck.removeCard(0);
            rightCard = cDeck.removeCard(0);
            cDeck.addCard(u);
            cDeck.addCard(c);
        }
        //If the user's and computer's top card have the same value
        else {
            leftCard = uDeck.removeCard(0);
            rightCard = cDeck.removeCard(0);
            while(u.getValue() == c.getValue() && count < uDeck.getSize() &&
                    count < cDeck.getSize()) {
                jTextArea1.append("The Cards are Equal!" + "\n");
                count = count + 3;
                if (uDeck.getSize() > count && cDeck.getSize() > count) {
                    jTextArea1.append("Milling 3 cards" + "\n");
                    u = uDeck.getCard(count);
                    c = cDeck.getCard(count);
                }
                //Occurs if either deck does not have the sufficient cards to "mill"
                else {
                    if (uDeck.getSize() <= count) {
                        u = uDeck.getCard(uDeck.getSize() - 1);
                        c = cDeck.getCard(uDeck.getSize() - 1);
                        count = uDeck.getSize();
                        jTextArea1.append("Milling " + (count - 1) + " cards" + "\n");
                    }
                    if (cDeck.getSize() <= count) {
                        u = uDeck.getCard(cDeck.getSize() - 1);
                        c = cDeck.getCard(cDeck.getSize() - 1);
                        count = cDeck.getSize();
                        jTextArea1.append("Milling " + (count - 1) + " cards" + "\n");
                    }
                }
            }
            if (u.getValue() > c.getValue()) {
                jTextArea1.append("Your " + u.toString() + " is greater than " + c.toString() + "\n");
                uDeck.addCard(u);
                uDeck.addCard(c);
                for (int i = 0; i < count; i++) {
                    uDeck.addCard(uDeck.removeCard(0));
                    uDeck.addCard(cDeck.removeCard(0));
                }
            } else if (u.getValue() < c.getValue()){
                jTextArea1.append("The Computer's " + c.toString() + " is greater than " + u.toString() + "\n");
                cDeck.addCard(u);
                cDeck.addCard(c);
                for (int i = 0; i < count; i++) {
                    cDeck.addCard(uDeck.removeCard(0));
                    cDeck.addCard(cDeck.removeCard(0));
                }
            } else {
                if (uDeck.getSize() > cDeck.getSize()) {
                    jTextArea1.append("The Computer has no more cards!" + "\n");
                    for (int i = 0; i < count; i++) {
                        uDeck.addCard(uDeck.removeCard(0));
                        uDeck.addCard(cDeck.removeCard(0));
                    }
                } else {
                    jTextArea1.append("You have no more cards!" + "\n");
                    for (int i = 0; i < count; i++) {
                        cDeck.addCard(uDeck.removeCard(0));
                        cDeck.addCard(cDeck.removeCard(0));
                    }
                }
            }
        }
        uDeck.shuffle();
        cDeck.shuffle();
        userDeck = uDeck;
        computerDeck = cDeck;
        jTextArea1.append("Your Deck: " + uDeck.getSize() + "\n");
        jTextArea1.append("Computer's Deck: " + cDeck.getSize() + "\n");
        jTextArea1.append(uDeck.toString() + "\n");
        jTextArea1.append(cDeck.toString() + "\n");
        jTextArea1.append("\n");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jLabel9 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cDeck = new javax.swing.JLabel();
        player = new javax.swing.JLabel();
        pCard = new javax.swing.JLabel();
        computer = new javax.swing.JLabel();
        pDeck = new javax.swing.JLabel();
        cCard = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        nextMove = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        automate = new javax.swing.JButton();
        startOver = new javax.swing.JButton();

        jLabel9.setText("Continue? (Y/N)");

        jButton2.setText("Yes");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(295, Short.MAX_VALUE))
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addComponent(jButton2)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2)
                .addContainerGap(228, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Let's get lit ;)))");

        cDeck.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cardgame/images/deck.jpg"))); // NOI18N

        player.setText("Player 1");

        pCard.setToolTipText("");

        computer.setText("Computer");

        pDeck.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cardgame/images/deck.jpg"))); // NOI18N

        cCard.setToolTipText("");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel8.setText("Output:");

        nextMove.setText("Start Game");
        nextMove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextMoveActionPerformed(evt);
            }
        });

        Back.setText("Lemme try a new game");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        automate.setText("Automate");
        automate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                automateActionPerformed(evt);
            }
        });

        startOver.setText("Start Over");
        startOver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startOverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(startOver)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nextMove)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(automate)
                .addGap(43, 43, 43))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(player)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(computer)
                        .addGap(233, 233, 233))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(pDeck, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pCard)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cCard)
                        .addGap(18, 18, 18)
                        .addComponent(cDeck, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 761, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel8))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Back)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Back))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(player)
                    .addComponent(computer))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cDeck, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pCard)
                            .addComponent(pDeck, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addComponent(jLabel8))
                    .addComponent(cCard))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nextMove)
                    .addComponent(automate)
                    .addComponent(startOver))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nextMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextMoveActionPerformed
        //Plays War as long as either Deck's size is not 0
        nextMove.setText("Next Move");
        if (userDeck.deck().size() != 0 && computerDeck.deck().size() != 0) {
            playWar(userDeck, computerDeck);
            if (userDeck.deck().size() <= 1) {
                pDeck.setVisible(false);
            } else if (computerDeck.deck().size() <= 1) {
                cDeck.setVisible(false);
            }
            updateGUI();
        }
        else if (computerDeck.deck().size() == 0) {
            jTextArea1.append("Game Over: You Win!");
        } else {
            pDeck.setVisible(false);
            jTextArea1.append("Game Over: You Lose!");
        }
    }//GEN-LAST:event_nextMoveActionPerformed

    public void updateGUI() {
        String fileName = convertToFile(leftCard.toString());
        pCard.setIcon(new javax.swing.ImageIcon(getClass().getResource(fileName)));
        fileName = convertToFile(rightCard.toString());
        cCard.setIcon(new javax.swing.ImageIcon(getClass().getResource(fileName)));
    }
    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        new Cardgame().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackActionPerformed

    private void automateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_automateActionPerformed
        while (userDeck.deck().size() != 0 && computerDeck.deck().size() != 0) {
            playWar(userDeck, computerDeck);
            if (userDeck.deck().size() <= 1) {
                pDeck.setVisible(false);
            } else if (computerDeck.deck().size() <= 1) {
                cDeck.setVisible(false);
            }
        }
        updateGUI();
        if (computerDeck.deck().size() == 0) {
            cDeck.setVisible(false);
            jTextArea1.append("Game Over: You Win!");
            
        } else {
            pDeck.setVisible(false);
            jTextArea1.append("Game Over: You Lose!");
        }
    }//GEN-LAST:event_automateActionPerformed

    private void startOverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startOverActionPerformed
        cDeck.setVisible(true);
        pDeck.setVisible(true);
        pCard.setIcon(null);
        cCard.setIcon(null);
        nextMove.setText("Start Game");
        userDeck = new Deck();
        computerDeck = new Deck();
        jTextArea1.setText(null);
        initDeck();
    }//GEN-LAST:event_startOverActionPerformed

    public String convertToFile(String card) {
        card = card.toLowerCase().replaceAll("\\s", "_");
        //improvement: use HashMap implementation
        if (card.substring(0,3).equals("one")) {
            card = "1" + card.substring(3);
        } else if (card.substring(0,3).equals("two")) {
            card = "2" + card.substring(3);
        } else if (card.substring(0,5).equals("three")) {
            card = "3" + card.substring(5);
        } else if (card.substring(0,4).equals("four")) {
            card = "4" + card.substring(4);
        } else if (card.substring(0,4).equals("five")) {
            card = "5" + card.substring(4);
        } else if (card.substring(0,3).equals("six")) {
            card = "6" + card.substring(3);
        } else if (card.substring(0,5).equals("seven")) {
            card = "7" + card.substring(5);
        } else if (card.substring(0,5).equals("eight")) {
            card = "8" + card.substring(5);
        } else if (card.substring(0,4).equals("nine")) {
            card = "9" + card.substring(4);
        } else if (card.substring(0,3).equals("ten")) {
            card = "10" + card.substring(3);
        }
        return "/cardgame/images/" + card + ".png";
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        Runnable x = new Runnable() {
            public void run() {
                new War().setVisible(true);
            }
        };
        java.awt.EventQueue.invokeLater(x);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JButton automate;
    private javax.swing.JLabel cCard;
    private javax.swing.JLabel cDeck;
    private javax.swing.JLabel computer;
    private javax.swing.JButton jButton2;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton nextMove;
    private javax.swing.JLabel pCard;
    private javax.swing.JLabel pDeck;
    private javax.swing.JLabel player;
    private javax.swing.JButton startOver;
    // End of variables declaration//GEN-END:variables
}
