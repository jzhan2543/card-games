/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardgame;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;
import java.awt.Image;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author tonyzhang
 */
public class War extends javax.swing.JFrame {

    /**
     * Creates new form War
     */
    public War() {
        initComponents();
        //Creates and shuffles a new deck, seperates the deck evenly to two decks;
        boolean acehigh = true;
        Deck deck = new Deck(acehigh);
        deck.shuffle();
        //Deck userDeck = new Deck();
        for (int i = 0; i < 26; i++) {
            userDeck.addCard(deck.getCard(i),i);
        }
        //Deck computerDeck = new Deck();
        for (int i = 26; i < 52; i++) {
            computerDeck.addCard(deck.getCard(i),i - 26);
        }
        System.out.println("Before button: " );
        System.out.println(userDeck.toString());
        System.out.println(computerDeck.toString());
    }

    public static Deck userDeck = new Deck();
    public static Deck computerDeck = new Deck();
    public static Card leftCard;
    public static Card rightCard;

    public void playWar(Deck uDeck, Deck cDeck) {
        int count = 0;
        //Create two new temporary decks to be assigned after War
        Deck newUserDeck = new Deck();
        Deck newComputerDeck = new Deck();
        //Creates two Cards that are the top cards of the user's and computer's deck
        Card u = uDeck.getCard(0);
        Card c = cDeck.getCard(0);
        //If the user's top card is larger
        if (u.getValue() > c.getValue()) {
            jTextArea1.append("Your " + u.toString() + " is greater than " + c.toString() + "\n");
            leftCard = uDeck.removeCard(0);
            rightCard = cDeck.removeCard(0);
            uDeck.addCard(u);
            uDeck.addCard(c);
        }
        //If the computer's top card is larger
        else if (u.getValue() < c.getValue()) {
            jTextArea1.append("The Computer's " + c.toString() + " is greater than " + u.toString() + "\n");
            leftCard = uDeck.removeCard(0);
            rightCard = cDeck.removeCard(0);
            cDeck.addCard(u);
            cDeck.addCard(c);
        }
        //If the user's and computer's top card have the same value
        else {
            leftCard = uDeck.removeCard(0);
            rightCard = cDeck.removeCard(0);
            while(u.getValue() == c.getValue() && count < uDeck.getSize() &&
                    count < cDeck.getSize()) {
                jTextArea1.append("The Cards are Equal!" + "\n");
                count = count + 3;
                if (uDeck.getSize() > count && cDeck.getSize() > count) {
                    jTextArea1.append("Milling 3 cards" + "\n");
                    u = uDeck.getCard(count);
                    c = cDeck.getCard(count);
                }
                //Occurs if either deck does not have the sufficient cards to "mill"
                else {
                    if (uDeck.getSize() <= count) {
                        u = uDeck.getCard(uDeck.getSize() - 1);
                        c = cDeck.getCard(uDeck.getSize() - 1);
                        count = uDeck.getSize();
                        jTextArea1.append("Milling " + (count - 1) + " cards" + "\n");
                    }
                    if (cDeck.getSize() <= count) {
                        u = uDeck.getCard(cDeck.getSize() - 1);
                        c = cDeck.getCard(cDeck.getSize() - 1);
                        count = cDeck.getSize();
                        jTextArea1.append("Milling " + (count - 1) + " cards" + "\n");
                    }
                }
            }
            if (u.getValue() > c.getValue()) {
                jTextArea1.append("Your " + u.toString() + " is greater than " + c.toString() + "\n");
                uDeck.addCard(u);
                uDeck.addCard(c);
                for (int i = 0; i < count; i++) {
                    uDeck.addCard(uDeck.removeCard(0));
                    uDeck.addCard(cDeck.removeCard(0));
                }
            } else if (u.getValue() < c.getValue()){
                jTextArea1.append("The Computer's " + c.toString() + " is greater than " + u.toString() + "\n");
                cDeck.addCard(u);
                cDeck.addCard(c);
                for (int i = 0; i < count; i++) {
                    cDeck.addCard(uDeck.removeCard(0));
                    cDeck.addCard(cDeck.removeCard(0));
                }
            } else {
                if (uDeck.getSize() > cDeck.getSize()) {
                    jTextArea1.append("The Computer has no more cards!" + "\n");
                    for (int i = 0; i < count; i++) {
                        uDeck.addCard(uDeck.removeCard(0));
                        uDeck.addCard(cDeck.removeCard(0));
                    }
                } else {
                    jTextArea1.append("You have no more cards!" + "\n");
                    for (int i = 0; i < count; i++) {
                        cDeck.addCard(uDeck.removeCard(0));
                        cDeck.addCard(cDeck.removeCard(0));
                    }
                }
            }
        }
        uDeck.shuffle();
        cDeck.shuffle();
        userDeck = uDeck;
        computerDeck = cDeck;
        jTextArea1.append("Your Deck: " + uDeck.getSize() + "\n");
        jTextArea1.append("Computer's Deck: " + cDeck.getSize() + "\n");
        jTextArea1.append(uDeck.toString() + "\n");
        jTextArea1.append(cDeck.toString() + "\n");
        jTextArea1.append("\n");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jLabel9 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        nextMove = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        automate = new javax.swing.JButton();

        jLabel9.setText("Continue? (Y/N)");

        jButton2.setText("Yes");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(295, Short.MAX_VALUE))
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addComponent(jButton2)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2)
                .addContainerGap(228, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Let's get lit ;)))");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cardgame/images/deck.jpg"))); // NOI18N

        jLabel3.setText("Player 1");

        jLabel4.setToolTipText("");

        jLabel5.setText("Computer");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cardgame/images/deck.jpg"))); // NOI18N

        jLabel7.setToolTipText("");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel8.setText("Output:");

        nextMove.setText("Start Game");
        nextMove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextMoveActionPerformed(evt);
            }
        });

        jButton4.setText("Nah, I'm bored");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        automate.setText("Automate");
        automate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                automateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nextMove)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(automate)
                .addGap(43, 43, 43))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel1)
                                .addGap(32, 32, 32)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(233, 233, 233))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 761, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel8)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(94, 94, 94)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nextMove)
                    .addComponent(jButton4)
                    .addComponent(automate))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nextMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextMoveActionPerformed
        //Plays War as long as either Deck's size is not 0
        nextMove.setText("Next Move");
        if (userDeck.deck().size() != 0 && computerDeck.deck().size() != 0) {
            playWar(userDeck, computerDeck);
            System.out.println("After button: " );
            System.out.println(userDeck.toString());
            System.out.println(computerDeck.toString());
            updateGUI();
        }
        else if (computerDeck.deck().size() == 0) {
            jTextArea1.append("Game Over: You Win!");
        } else {
            jTextArea1.append("Game Over: You Lose!");
        }
    }//GEN-LAST:event_nextMoveActionPerformed

    public void updateGUI() {
        String fileName = convertToFile(leftCard.toString());
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource(fileName)));
        fileName = convertToFile(rightCard.toString());
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource(fileName)));
    }
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void automateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_automateActionPerformed
        while (userDeck.deck().size() != 0 && computerDeck.deck().size() != 0) {
            playWar(userDeck, computerDeck);
            System.out.println("After button: " );
            System.out.println(userDeck.toString());
            System.out.println(computerDeck.toString());
        }
        updateGUI();
        if (computerDeck.deck().size() == 0) {
            jTextArea1.append("Game Over: You Win!");
        } else {
            jTextArea1.append("Game Over: You Lose!");
        }
    }//GEN-LAST:event_automateActionPerformed

    public String convertToFile(String card) {
        card = card.toLowerCase().replaceAll("\\s", "_");
        //improvement: use HashMap implementation
        if (card.substring(0,3).equals("one")) {
            card = "1" + card.substring(3);
        } else if (card.substring(0,3).equals("two")) {
            card = "2" + card.substring(3);
        } else if (card.substring(0,5).equals("three")) {
            card = "3" + card.substring(5);
        } else if (card.substring(0,4).equals("four")) {
            card = "4" + card.substring(4);
        } else if (card.substring(0,4).equals("five")) {
            card = "5" + card.substring(4);
        } else if (card.substring(0,3).equals("six")) {
            card = "6" + card.substring(3);
        } else if (card.substring(0,5).equals("seven")) {
            card = "7" + card.substring(5);
        } else if (card.substring(0,5).equals("eight")) {
            card = "8" + card.substring(5);
        } else if (card.substring(0,4).equals("nine")) {
            card = "9" + card.substring(4);
        } else if (card.substring(0,3).equals("ten")) {
            card = "10" + card.substring(3);
        }
        return "/cardgame/images/" + card + ".png";
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(War.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        Runnable x = new Runnable() {
            public void run() {
                new War().setVisible(true);
            }
        };
        java.awt.EventQueue.invokeLater(x);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton automate;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton nextMove;
    // End of variables declaration//GEN-END:variables
}
