package cardgame;

public enum Suit {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}